﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.feetDisplay = New System.Windows.Forms.TextBox()
        Me.solutionFeet = New System.Windows.Forms.Label()
        Me.Title = New System.Windows.Forms.Label()
        Me.userInput = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.inchesDisplay = New System.Windows.Forms.TextBox()
        Me.solutionInches = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'feetDisplay
        '
        Me.feetDisplay.Location = New System.Drawing.Point(54, 305)
        Me.feetDisplay.Name = "feetDisplay"
        Me.feetDisplay.Size = New System.Drawing.Size(283, 20)
        Me.feetDisplay.TabIndex = 0
        '
        'solutionFeet
        '
        Me.solutionFeet.AutoSize = True
        Me.solutionFeet.Location = New System.Drawing.Point(51, 289)
        Me.solutionFeet.Name = "solutionFeet"
        Me.solutionFeet.Size = New System.Drawing.Size(28, 13)
        Me.solutionFeet.TabIndex = 1
        Me.solutionFeet.Text = "Feet"
        '
        'Title
        '
        Me.Title.AutoSize = True
        Me.Title.Location = New System.Drawing.Point(320, 46)
        Me.Title.Name = "Title"
        Me.Title.Size = New System.Drawing.Size(76, 13)
        Me.Title.TabIndex = 2
        Me.Title.Text = "Convert Below"
        '
        'userInput
        '
        Me.userInput.Location = New System.Drawing.Point(54, 144)
        Me.userInput.Name = "userInput"
        Me.userInput.Size = New System.Drawing.Size(283, 20)
        Me.userInput.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(51, 128)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Enter Inches"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(54, 183)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 5
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'inchesDisplay
        '
        Me.inchesDisplay.Location = New System.Drawing.Point(54, 378)
        Me.inchesDisplay.Name = "inchesDisplay"
        Me.inchesDisplay.Size = New System.Drawing.Size(283, 20)
        Me.inchesDisplay.TabIndex = 6
        '
        'solutionInches
        '
        Me.solutionInches.AutoSize = True
        Me.solutionInches.Location = New System.Drawing.Point(51, 362)
        Me.solutionInches.Name = "solutionInches"
        Me.solutionInches.Size = New System.Drawing.Size(39, 13)
        Me.solutionInches.TabIndex = 7
        Me.solutionInches.Text = "Inches"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(696, 378)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(165, 183)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "C&lear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.solutionInches)
        Me.Controls.Add(Me.inchesDisplay)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.userInput)
        Me.Controls.Add(Me.Title)
        Me.Controls.Add(Me.solutionFeet)
        Me.Controls.Add(Me.feetDisplay)
        Me.Name = "frmMain"
        Me.Text = "Measurement Converter"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents feetDisplay As TextBox
    Friend WithEvents solutionFeet As Label
    Friend WithEvents Title As Label
    Friend WithEvents userInput As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents inchesDisplay As TextBox
    Friend WithEvents solutionInches As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
End Class
