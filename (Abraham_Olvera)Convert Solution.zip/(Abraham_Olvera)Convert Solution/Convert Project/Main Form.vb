﻿Public Class frmMain
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles solutionFeet.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles feetDisplay.TextChanged

    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Title.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        feetDisplay.Text = userInput.Text \ 12
        inchesDisplay.Text = userInput.Text Mod 12

    End Sub

    Private Sub userInput_TextChanged(sender As Object, e As EventArgs) Handles userInput.TextChanged

    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs) Handles inchesDisplay.TextChanged

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        userInput.Text = Nothing
        feetDisplay.Text = Nothing
        inchesDisplay.Text = Nothing
    End Sub
End Class
